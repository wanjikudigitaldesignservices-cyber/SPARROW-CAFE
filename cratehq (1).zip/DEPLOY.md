# Deploying CrateHQ to Vercel

## Prerequisites
- Vercel account (vercel.com)
- MongoDB Atlas cluster (or Railway/Render MongoDB)
- Twilio account (optional, for SMS)

## Step 1: Environment Variables

Add these in Vercel Dashboard → Project Settings → Environment Variables:

```
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/cratehq
NEXTAUTH_SECRET=your_random_secret_here
NEXTAUTH_URL=https://your-project.vercel.app
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890
```

## Step 2: Deploy

```bash
npm i -g vercel
vercel --prod
```

Or connect your GitHub repo to Vercel for auto-deployments.

## Important Notes

1. **MongoDB**: Use MongoDB Atlas (cloud) instead of localhost for production.
2. **Puppeteer**: Uses @sparticuz/chromium for serverless compatibility.
3. **Images**: The `images.unoptimized: true` setting is enabled for static export compatibility.
4. **NextAuth**: Update `NEXTAUTH_URL` to match your production domain.
5. **Leaflet Maps**: Works out of the box on Vercel (client-side rendered).

## Local Development

```bash
npm install
npm run dev
```

Make sure MongoDB is running locally or update `.env.local` with your Atlas URI.
