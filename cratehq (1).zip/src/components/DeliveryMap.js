"use client";

import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x.src,
  iconUrl: markerIcon.src,
  shadowUrl: markerShadow.src
});

const retailerIcon = new L.Icon({
  iconUrl: markerIcon.src,
  iconRetinaUrl: markerIcon2x.src,
  shadowUrl: markerShadow.src,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
  className: "filter hue-rotate-180"
});

const agentIcon = new L.Icon({
  iconUrl: markerIcon.src,
  iconRetinaUrl: markerIcon2x.src,
  shadowUrl: markerShadow.src,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
  className: "filter hue-rotate-90"
});

export default function DeliveryMap() {
  const [data, setData] = useState({ users: [], orders: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const res = await fetch("/api/map");
      const d = await res.json();
      setData(d);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  }

  if (loading) return <div className="h-96 bg-gray-100 rounded-xl flex items-center justify-center text-gray-500">Loading map...</div>;

  const retailers = data.users.filter((u) => u.role === "retailer");
  const agents = data.users.filter((u) => u.role === "delivery_agent");

  return (
    <div className="h-96 rounded-xl overflow-hidden border">
      <MapContainer center={[-1.2921, 36.8219]} zoom={11} scrollWheelZoom={true} style={{ height: "100%", width: "100%" }}>
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {retailers.map((u) => (
          <Marker key={u._id} position={[u.location.lat, u.location.lng]} icon={retailerIcon}>
            <Popup>
              <div className="text-sm">
                <p className="font-bold">{u.name}</p>
                <p className="text-gray-600">Retailer</p>
                <p>{u.phone}</p>
              </div>
            </Popup>
          </Marker>
        ))}
        {agents.map((u) => (
          <Marker key={u._id} position={[u.location.lat, u.location.lng]} icon={agentIcon}>
            <Popup>
              <div className="text-sm">
                <p className="font-bold">{u.name}</p>
                <p className="text-gray-600">Delivery Agent</p>
                <p>{u.phone}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
