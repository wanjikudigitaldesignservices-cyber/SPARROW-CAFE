"use client";

import Link from "next/link";
import { signOut } from "next-auth/react";

export default function Navbar({ session }) {
  const role = session?.user?.role;
  const roleLabel =
    role === "delivery_agent"
      ? "Delivery Agent"
      : role?.charAt(0).toUpperCase() + role?.slice(1);

  let dashboardLink = "/dashboard/retailer";
  if (role === "distributor") dashboardLink = "/dashboard/distributor";
  if (role === "delivery_agent") dashboardLink = "/dashboard/delivery";

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href={dashboardLink} className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#D85A30]"></div>
          <span className="text-xl font-bold text-gray-900">CrateHQ</span>
        </Link>
        <div className="flex items-center gap-4">
          <span className="px-3 py-1 bg-orange-100 text-[#D85A30] rounded-full text-sm font-medium capitalize">
            {roleLabel}
          </span>
          <button
            onClick={() => signOut({ callbackUrl: "/" })}
            className="text-sm text-gray-600 hover:text-gray-900 font-medium"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}
