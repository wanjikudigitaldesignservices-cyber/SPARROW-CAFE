"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";

const DeliveryMap = dynamic(() => import("@/components/DeliveryMap"), {
  ssr: false,
  loading: () => <div className="h-64 bg-gray-100 rounded-xl flex items-center justify-center text-gray-500 text-sm">Loading map...</div>
});

export default function DeliveryDashboard() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchOrders(); }, []);

  async function fetchOrders() {
    setLoading(true);
    try {
      const res = await fetch("/api/orders");
      const data = await res.json();
      setOrders(data);
    } catch (err) { console.error(err); }
    setLoading(false);
  }

  if (loading) return <div className="text-center py-12 text-gray-600">Loading orders...</div>;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">My Deliveries</h2>

      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="text-sm font-bold text-gray-700 mb-2">Delivery Map</h3>
        <DeliveryMap />
      </div>

      {orders.length === 0 && <div className="bg-white rounded-xl shadow-sm p-8 text-center text-gray-500">No dispatched orders assigned to you</div>}

      {orders.map((order) => (
        <DeliveryCard key={order._id} order={order} onComplete={fetchOrders} />
      ))}
    </div>
  );
}

function DeliveryCard({ order, onComplete }) {
  const [returnStatus, setReturnStatus] = useState("full");
  const [bottlesReturned, setBottlesReturned] = useState(0);
  const [notes, setNotes] = useState("");
  const [photo, setPhoto] = useState(null);
  const [location, setLocation] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [locError, setLocError] = useState("");

  const totalCrates = order.crates?.length || 0;
  const totalSlots = order.crates?.reduce((sum, c) => sum + (c.slotsTotal || 0), 0) || 0;

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => setLocError("Location access denied or unavailable")
      );
    } else {
      setLocError("Geolocation not supported");
    }
  }, []);

  function handlePhotoChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setPhoto(reader.result);
    reader.readAsDataURL(file);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);

    const payload = {
      orderId: order._id,
      cratesDelivered: totalCrates,
      bottlesReturned: returnStatus === "full" ? totalSlots : returnStatus === "none" ? 0 : Number(bottlesReturned),
      returnStatus,
      notes
    };

    if (location) payload.deliveryLocation = location;
    if (photo) payload.deliveryPhoto = photo;

    try {
      const res = await fetch("/api/bottle-returns", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      setSubmitting(false);
      if (res.ok) onComplete();
    } catch (err) { setSubmitting(false); console.error(err); }
  }

  if (order.status === "delivered") {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-lg">{order.retailer?.name}</h3>
            <p className="text-sm text-gray-500">{order.retailer?.phone}</p>
          </div>
          <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">Delivered</span>
        </div>
        <div className="mt-3 text-sm text-gray-600">
          {order.crates?.map((c, i) => <span key={i} className="mr-3">{c.crateType}: {c.slotsTotal} units</span>)}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="mb-4">
        <h3 className="font-bold text-lg">{order.retailer?.name}</h3>
        <p className="text-sm text-gray-500">{order.retailer?.phone}</p>
        {order.retailer?.location?.lat && (
          <p className="text-xs text-gray-400 mt-1">Location: {order.retailer.location.lat.toFixed(4)}, {order.retailer.location.lng.toFixed(4)}</p>
        )}
      </div>

      <div className="text-sm text-gray-600 mb-4">
        {order.crates?.map((c, i) => <span key={i} className="mr-3">{c.crateType}: {c.slotsTotal} units</span>)}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Bottle Return</label>
          <div className="flex gap-2">
            {["full", "partial", "none"].map((status) => (
              <button key={status} type="button" onClick={() => setReturnStatus(status)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition ${
                  returnStatus === status ? "bg-[#D85A30] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}>
                {status === "full" ? "Full Return" : status === "partial" ? "Partial" : "None"}
              </button>
            ))}
          </div>
        </div>

        {returnStatus === "partial" && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bottles Returned</label>
            <input type="number" min="0" max={totalSlots} value={bottlesReturned} onChange={(e) => setBottlesReturned(e.target.value)} className="w-full px-4 py-2 border rounded-lg" required />
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Photo</label>
          <input type="file" accept="image/*" onChange={handlePhotoChange} className="w-full text-sm" />
          {photo && <img src={photo} alt="Preview" className="mt-2 h-32 object-cover rounded-lg border" />}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full px-4 py-2 border rounded-lg" rows={3} />
        </div>

        <div className="flex items-center gap-2 text-sm">
          {location ? (
            <span className="text-green-600 font-medium">GPS captured: {location.lat.toFixed(5)}, {location.lng.toFixed(5)}</span>
          ) : (
            <span className="text-amber-600">{locError || "Capturing location..."}</span>
          )}
        </div>

        <button type="submit" disabled={submitting || !location}
          className="w-full py-3 bg-[#D85A30] text-white rounded-xl font-medium hover:bg-[#c44e28] transition disabled:opacity-50">
          {submitting ? "Confirming..." : "Confirm Delivery"}
        </button>
      </form>
    </div>
  );
}
