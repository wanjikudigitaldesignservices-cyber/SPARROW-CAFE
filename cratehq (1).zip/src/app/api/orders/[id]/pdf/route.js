import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import dbConnect from "@/lib/mongodb";
import Order from "@/lib/models/Order";
import OrderCrate from "@/lib/models/OrderCrate";
import CrateItem from "@/lib/models/CrateItem";
import Product from "@/lib/models/Product";
import User from "@/lib/models/User";
import { generateOrderPDF } from "@/lib/pdf";

export async function GET(req, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    await dbConnect();
    const { id } = params;

    const order = await Order.findById(id).lean();
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (session.user.role === "retailer" && order.retailerId.toString() !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }
    if (session.user.role === "delivery_agent" && order.assignedAgentId?.toString() !== session.user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const retailer = await User.findById(order.retailerId).lean();
    const agent = order.assignedAgentId ? await User.findById(order.assignedAgentId).lean() : null;

    const crates = await OrderCrate.find({ orderId: order._id }).lean();
    const cratesWithItems = await Promise.all(
      crates.map(async (crate) => {
        const items = await CrateItem.find({ crateId: crate._id }).lean();
        const itemsWithProduct = await Promise.all(
          items.map(async (item) => {
            const product = await Product.findById(item.productId).lean();
            return { ...item, product };
          })
        );
        return { ...crate, items: itemsWithProduct };
      })
    );

    const orderWithRefs = { ...order, agent };
    const pdfBuffer = await generateOrderPDF(orderWithRefs, retailer, cratesWithItems);

    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="cratehq-order-${id.slice(-6)}.pdf"`
      }
    });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
