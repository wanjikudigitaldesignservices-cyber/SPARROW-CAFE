import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import dbConnect from "@/lib/mongodb";
import User from "@/lib/models/User";
import Order from "@/lib/models/Order";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    await dbConnect();

    let users = [];
    let orders = [];

    if (session.user.role === "distributor") {
      users = await User.find({
        role: { $in: ["retailer", "delivery_agent"] },
        "location.lat": { $ne: null }
      }).select("name role phone location").lean();

      orders = await Order.find({ status: { $in: ["pending", "approved", "dispatched"] } })
        .populate("retailerId", "name location phone")
        .populate("assignedAgentId", "name location phone")
        .lean();
    } else if (session.user.role === "delivery_agent") {
      orders = await Order.find({
        assignedAgentId: session.user.id,
        status: { $in: ["dispatched", "delivered"] }
      })
        .populate("retailerId", "name location phone")
        .lean();

      const retailerIds = orders.map((o) => o.retailerId?._id).filter(Boolean);
      users = await User.find({
        _id: { $in: retailerIds },
        "location.lat": { $ne: null }
      }).select("name role phone location").lean();
    }

    return NextResponse.json({ users, orders });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
