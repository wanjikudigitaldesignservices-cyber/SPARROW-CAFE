import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import dbConnect from "@/lib/mongodb";
import BottleReturn from "@/lib/models/BottleReturn";
import Order from "@/lib/models/Order";
import User from "@/lib/models/User";
import { notifyDeliveryComplete } from "@/lib/sms";

export async function POST(req) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== "delivery_agent") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    await dbConnect();
    const { orderId, cratesDelivered, bottlesReturned, returnStatus, notes, deliveryLocation, deliveryPhoto } = await req.json();

    const returnData = {
      orderId,
      deliveryAgentId: session.user.id,
      cratesDelivered,
      bottlesReturned,
      returnStatus,
      notes
    };

    if (deliveryLocation && deliveryLocation.lat && deliveryLocation.lng) {
      returnData.deliveryLocation = deliveryLocation;
    }
    if (deliveryPhoto) {
      returnData.deliveryPhoto = deliveryPhoto;
    }

    await BottleReturn.create(returnData);
    await Order.findByIdAndUpdate(orderId, { status: "delivered" });

    const order = await Order.findById(orderId);
    if (order) {
      const retailer = await User.findById(order.retailerId);
      if (retailer && retailer.phone) {
        await notifyDeliveryComplete(retailer.phone, orderId, returnStatus);
      }
    }

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    await dbConnect();

    let query = {};
    if (session.user.role === "delivery_agent") {
      query.deliveryAgentId = session.user.id;
    }

    const returns = await BottleReturn.find(query).sort({ createdAt: -1 }).lean();
    const enriched = await Promise.all(
      returns.map(async (ret) => {
        const order = await Order.findById(ret.orderId).lean();
        const retailer = order ? await User.findById(order.retailerId).lean() : null;
        const agent = await User.findById(ret.deliveryAgentId).lean();
        return { ...ret, order, retailer, agent };
      })
    );

    return NextResponse.json(enriched);
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
